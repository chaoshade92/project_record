// 각 router 작성자 정리
// 이명일 : post / Login / IdSelector / PwSelector / PwUpdate / Logout / main
// 석효희 : memo / cit_list / cited_list / memo_print
// 김희소 : map / sealist / mark / book_on

// 라우터 실행에 필요한 모듈 호출
const express = require("express");
const router = express.Router();
const conn = require("../config/DB_config");
const ejs = require("ejs");
const fs = require('fs');

// 회원가입
router.post("/Join", function(request, response){

    let user_id = request.body.id;
    let user_pw = request.body.pw;
    let user_name = request.body.name;
    let user_email = request.body.email;
    
    conn.connect();    
    
    // DB user 테이블에 회원가입 정보 입력
    let sql2 = "insert into login values(?, ?, ?, ?, now())";
    
    conn.query(sql2,[user_id, user_pw, user_email, user_name], function(err,row){
        if(!err){
            console.log(user_name+"님이 회원가입 하였습니다.");
            response.redirect("http://222.102.104.70:/main.html");//로그인전 메인페이지 이동
        }else{
            console.log("누군가 회원가입에 실패하였습니다.");
            response.redirect("http://222.102.104.70:/publi/Join.html"); // 회원가입 페이지 이동
        }

    })

    // 회원가입한 사용자의 북마크 환경(3개의 폴더에 사용자 정보 저장) 초기화
    for(let temp = 1; temp<4; temp++){
        let temp2 = ("폴더"+temp);
        console.log(temp2);
        let sql1 = "insert into folder values (?,?,?);"
        conn.query(sql1,[user_id, temp, temp2], function(err,row){
            console.log(user_id+temp+temp2+" ");
        })
        }
    conn.end();
});

// 로그인
router.post("/Login", function(request, response){
    let user_id = request.body.id;
    let user_pw = request.body.pw;

    conn.connect();

    // DB에 사용자의 id 검색
    let sql = "select * from login where user_id = ?";

    conn.query(sql, [user_id], function(err,row){
        if(row.length > 0){
            for(let i = 0 ; i < row.length; i++){
                if(user_pw == row[i].user_pw){ //검색된 ID가 있을 때 비교
                    // console.log(row[i].user_id);

                    request.session.user = {
                        "name" : row[i].user_name
                    } // 세션에 유저 이름 저장
                    response.render("ma2",{
                        id : row[i].user_id,
                        name : row[i].user_name
                    }) // 메인페이지 ejs에 id, name 데이터 전송
                    
                    // 로그인 후 메인페이지 이동
                }
                else{
                    console.log("로그인 실패");
                    response.redirect("http://222.102.104.70:5500/public/LoginF.html") //로그인 실패시 로그인창 이동
                    
                }
            }
        }else{//검색된 id가 없을때
            console.log("로그인 실패");
            response.redirect("http://222.102.104.70:5500/public/LoginF.html")// 로그인 실패시 로그인창 이동
        }
    });
    conn.end();
});

router.get("/main", function(request, response){
    let user_id = request.query.id;

    conn.connect();

    let sql = "select * from login where user_id = ?";

    conn.query(sql, [user_id], function(err,row){
        console.log(row+"");
        if(row != ""){
            request.session.user = {
                "name" : row[0].user_name
            }

            response.render("ma2",{
                id : row[0].user_id,
                name : row[0].user_name,
            })
        }else{
            response.render("ma2",{
                name : "no",
                id : "no"
            })

        }
    })
    conn.end();
});

// 아이디 찾기
router.post("/IdSelector", function(request, response){
    let user_email = request.body.email;

    conn.connect();

    let sql = "select * from login where user_email = ?";

    conn.query(sql, [user_email], function(err, row){
        if(row.length>0){
            console.log(err);
            for(let i = 0; i < row.length; i++){
                if(user_email==row[i].user_email){//입력한 메일과 db에 저장된 메일 비교
                    response.render("IdSelectorS",{
                        name : row[i].user_name,
                        id : row[i].user_id
                    });
                }
                else{//해당 메일로 가입한 아이디가 없을경우
                    console.log("해당 메일로 가입한 아이디가 없습니다.");
                    response.redirect("http://222.102.104.70:5500/public/IdSelectorF.html")
                }
            }
        }
        else{
            console.log("해당 메일로 가입한 아이디가 없습니다.");
            response.redirect("http://222.102.104.70:5500/public/IdSelectorF.html")
        }
    });
    conn.end();
});

// 비밀번호 찾기
router.post("/PwSelector", function(request, response){
    let user_id = request.body.id;
    let user_email = request.body.email;

    conn.connect();

    let sql = "select * from login where user_id = ?"

    conn.query(sql, [user_id], function(err,row){
        if(row.length > 0){
            console.log(err);
            for(let i = 0; i < row.length; i++){
                if(user_id == row[i].user_id && user_email==row[i].user_email){
                    request.session.user={
                        "id" : row[i].user_id
                    }
                    response.render("PwUpdate",{
                        id : row[i].user_id
                    })

                    response.redirect("http://222.102.104.70:5500/public/PwUpdate.html")
                }else{
                    //알럿창으로 다시 입력 하게 하거나 회원가입 창으로 넘어가게 함.
                    response.redirect("http://222.102.104.70:5500/public/PwSelectorF.html")
                }
            }
        }else{
            response.redirect("http://222.102.104.70:5500/public/PwSelectorF.html")
        }
    });
    conn.end();
})

// 비밀번호 찾기
router.post("/PwUpdate",function(request,response){
    let user_id = request.session.user.id
    let user_pw = request.body.pw;

    conn.connect();//mysql연결

    let sql ="update login set user_pw = ? where user_id = ?";

    conn.query(sql,[user_pw, user_id.id] ,function(err, row){
        if(row.length > 0){
            console.log(err);
            for(let i = 0; i < row.length; i++){
                if(user_id == row[i].user_id && user_email==row[i].user_email){
                    request.session.user ={
                        "id" : row[i].user_id.id
                    }

                    // response.redirect("http://127.0.0.1:5500/window_nodejs/public/PwUpdate.html")
                }else{
                    //알럿창으로 다시 입력 하게 하거나 회원가입 창으로 넘어가게 함.
                    response.redirect("http://127.0.0.1:5500/window_nodejs/public/PwSelectorF.html")
                }
            }
        }else{
            response.redirect("http://127.0.0.1:5500/window_nodejs/public/PwSelectorF.html")
        }
    });
    conn.end();
});

// 검색 결과 출력
router.get("/sealist", function(request, response){

    let sea = request.query.sea;

    conn.connect(); //mysql 연결
    let keyword = "%" + sea + "%";

    let sql = "select * from article where article_title like ?";
    conn.query(sql, [keyword], function (err, row) {
        // console.log(row);
        response.send(row);
    })

})


router.get("/bookon", function(request, response){

    let id = request.query.id;
    let art = request.query.art;
    let folnum = request.query.folnum;
    console.log(`${id}, ${art}, ${folnum}`);
    conn.connect(); //mysql 연결



    let sql = "INSERT INTO bookmark(user_id, folder_id, article_id) VALUES (?, ?, ?)";
    conn.query(sql, [id, folnum, art], function (err, row) {
        response.send(row);
    })

})

//팝업 띄울 때 폴더이름 출력
router.post("/mark", function(request, response){
    let id=request.body.id;
    let art=request.body.art;
    // console.log(`${art}`);
    conn.connect();
    // console.log(row);

    let sql = "select * from folder where user_id = ?";
    conn.query(sql, [id], function(err,row){
        // console.log(row+"this");
            response.render("book_pop",{
                in_row: row,
                in_art: art,
                in_id: id
            })    
    })
    conn.end();
});

// 인용 목록 출력
router.get("/cit_list", function(request, response){

    let sea = parseInt(request.query.sea);

    conn.connect(); //mysql 연결
    let article_id = sea;

    let sql = "select * from article where citation_id = ? ";
    conn.query(sql, [article_id], function (err, row) {
        // console.log(row);
        response.send(row);
    })

})

// 피인용 목록 출력
router.get("/cited_list", function(request, response){

    let sea = parseInt(request.query.sea);
    

    conn.connect(); //mysql 연결
    let article_id = sea;

    let sql = "select * from article where article_id = (select citation_id from article where article_id = ?)"
    conn.query(sql, [article_id], function (err, row) {
        console.log(err);
        response.send(row);
    })
});

// 북마크 기록 확인
router.get("/memo_ck", function(request, response){

    let sea = parseInt(request.query.sea);
    let id = request.query.id;

    conn.connect(); //mysql 연결
    let article_id = sea;

    let sql = "SELECT * FROM bookmark WHERE article_id = ? and user_id = ? "
    conn.query(sql, [article_id, id], function (err, row) {
        // console.log(article_id);
        response.send(row);
    })
});

// DB에 메모 저장
router.get("/memo_in", function(request, response){

    let sea = parseInt(request.query.sea);
    let id = request.query.id + "";
    let memo = request.query.memo;
    conn.connect(); //mysql 연결

    let article_id = sea;

    let sql = "UPDATE bookmark SET memo = ? WHERE article_id = ? "
    conn.query(sql, [memo, article_id], function (err, row) {
        console.log(err);
        response.send(row);
    })

});

// DB에 저장된 메모 출력
router.get("/memo_print", function(request, response){

    let sea = parseInt(request.query.sea);
    let id = request.query.id;

    conn.connect(); //mysql 연결

    let article_id = sea;

    let sql = "select memo from bookmark WHERE article_id = ? and user_id = ?"
    conn.query(sql, [article_id, id], function (err, row) {
        // console.log(err);
        response.send(row);
    })

});

// 북마크 정보 출력
router.get("/searchFolder", function(request, response){
    
    let id = request.query.id;
    conn.connect(); //mysql 연결

    let sql = "select * from bookmark where user_id = ?";
    conn.query(sql, [id], function (err, row) {
        console.log(err);
        response.send(row);
    })

})

// 논문 아이디로 이름 등 부가정보 출력
router.get("/searchnum", function(request, response){
    
    let artid = request.query.artid;
    conn.connect(); //mysql 연결

    let sql = "select * from article where article_id like ?";
    conn.query(sql, [artid], function (err, row) {
        console.log(row);
        response.send(row);
    })

})

// 로그아웃
router.get("/Logout", function(request, response){

    request.session.destroy(function(){
        request.session;
    })

    response.render("ma2",{
        name : "no",
        id : "no"
    })

});

//map출력
router.post("/map", function(request, response){

    //북마크에 저장된 논문들의 id를 저장한 정보
    let numlist=request.body.numlist;
    console.log(numlist);
    //각 논문의 id를 확인하기 위해 numlist string을 parsing 함
    let numlistArray = numlist.split(" ");
    
    // index.js에 저장될 그래프 출력 스크립트 초기 설정
    var strin = `import cytoscape from 'cytoscape';import coseBilkent from 'cytoscape-cose-bilkent';cytoscape.use(coseBilkent);import './style.css';const data = [`;
            
    conn.connect(); //mysql 연결

    let sql = "select citation_id, article_title from article where article_id = ?";
    for(i = 0; i<numlistArray.length; i++){
        let k = numlistArray[i] // 북마크에 저장된 논문의 id 정보

        conn.query(sql, [k], function(err,row){
            try{
                for(j = 0; j<numlistArray.length; j++){
                    console.log(row[0]+"");
                    if(row[0].citation_id == numlistArray[j]){
                        // map 출력에 필요한 인용한아이디/인용된아이디 정보를 Node 형식에 맞춰서 strin 스크립트에 저장
                        strin += `{"data": { "id": "${numlistArray[j]}->${k}", "source": "${numlistArray[j]}", "target": "${k}" }},`;
                    }
                }

                console.log(row[0].article_title);
                // Node에 정보를 저장하는 논문의 제목을 label에 저장하는 스크립트를 추가
                strin += `{"data": {"id": "${k}","label": "${row[0].article_title}" }},`;
                console.log("here");
            }catch (error){
                console.log(error);
            }

        })
    }

    conn.query(sql, ["a"], function(err,row){
        
        // map 출력 데이터가 저장되는 index.js 파일에 node, graph 설정 코드를 추가함
        strin += `];const cy_for_rank = cytoscape({elements: data});const pageRank = cy_for_rank.elements().pageRank();const nodeMaxSize = 50;const nodeMinSize = 5;const fontMaxSize = 8;const fontMinSize = 5;const cy = cytoscape({container: document.getElementById('cy'), elements: data,style: [{selector: 'node',style: {'background-color': '#666','label': 'data(label)','width': function (ele) {return nodeMaxSize *  pageRank.rank('#' + ele.id())  + nodeMinSize;},'height': function (ele) {return nodeMaxSize *  pageRank.rank('#' + ele.id()) + nodeMinSize;},'font-size': function (ele) {return fontMaxSize *   pageRank.rank('#' + ele.id()) + fontMinSize;}}},{selector: 'edge',style: {'width': 3,'curve-style': 'bezier','line-color': '#ccc','source-arrow-color': '#ccc','source-arrow-shape': 'vee'}}],layout: {name: 'cose-bilkent',animate: false,gravityRangeCompound: 1.5,fit: true,tile: true}});`;
        console.log(strin);
        fs.writeFile('./../test4/src/index.js',strin,'utf8',function(err){ // 파일 내용 수정 
            console.log('write end') 
        });
        
    })

    response.writeHead(200, {"Content-Type" : "text/html;charset=utf-8"});

    // 맵 출력 url 지정
    response.write(`<meta http-equiv="refresh" content="0;URL='http://localhost:9000/'">`);

    response.end();


    conn.end();

});

module.exports = router;